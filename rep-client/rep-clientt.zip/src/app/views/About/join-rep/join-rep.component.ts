import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-join-rep',
  templateUrl: './join-rep.component.html',
  styleUrls: ['./join-rep.component.css']
})
export class JoinRepComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
