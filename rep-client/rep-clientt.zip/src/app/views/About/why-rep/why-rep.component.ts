import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-rep',
  templateUrl: './why-rep.component.html',
  styleUrls: ['./why-rep.component.css']
})
export class WhyRepComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
