import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-us-map',
  templateUrl: './contact-us-map.component.html',
  styleUrls: ['./contact-us-map.component.css']
})
export class ContactUsMapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
