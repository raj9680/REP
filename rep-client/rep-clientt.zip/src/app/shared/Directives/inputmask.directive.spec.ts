import { InputmaskDirective } from './inputmask.directive';

describe('InputmaskDirective', () => {
  it('should create an instance', () => {
    const directive = new InputmaskDirective();
    expect(directive).toBeTruthy();
  });
});
