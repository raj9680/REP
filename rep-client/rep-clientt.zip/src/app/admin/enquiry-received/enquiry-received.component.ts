import { Component } from '@angular/core';

@Component({
  selector: 'app-enquiry-received',
  templateUrl: './enquiry-received.component.html',
  styleUrls: ['./enquiry-received.component.css']
})
export class EnquiryReceivedComponent {

}
