import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-property-search',
  templateUrl: './property-search.component.html',
  styleUrls: ['./property-search.component.css']
})
export class PropertySearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
