import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-evaluation',
  templateUrl: './home-evaluation.component.html',
  styleUrls: ['./home-evaluation.component.css']
})
export class HomeEvaluationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
