import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-professional-detail',
  templateUrl: './our-professional-detail.component.html',
  styleUrls: ['./our-professional-detail.component.css']
})
export class OurProfessionalDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
