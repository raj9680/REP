export const environment = {
  production: true,
  apiEndpoint: 'https://musing-lehmann.108-175-0-196.plesk.page/'
};