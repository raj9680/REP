import { Component } from '@angular/core';

@Component({
  selector: 'app-realtors',
  templateUrl: './realtors.component.html',
  styleUrls: ['./realtors.component.css']
})
export class RealtorsComponent {

}
