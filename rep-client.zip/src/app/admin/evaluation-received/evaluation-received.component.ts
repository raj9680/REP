import { Component } from '@angular/core';

@Component({
  selector: 'app-evaluation-received',
  templateUrl: './evaluation-received.component.html',
  styleUrls: ['./evaluation-received.component.css']
})
export class EvaluationReceivedComponent {

}
